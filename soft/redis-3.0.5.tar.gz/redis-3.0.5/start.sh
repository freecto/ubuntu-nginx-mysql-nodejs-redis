ps -ef|grep redis|awk '{print $2}'|xargs sudo kill -9
/opt/redis-3.0.5/redis-server /opt/redis-3.0.5/redis.conf --notify-keyspace-events KExe &


